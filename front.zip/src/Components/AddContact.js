import React, { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';

const AddContact = ({ contact, setContact, local_storage_key }) => {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");


  // Get contacts from Add Contact component "contacts"
  const addContactHandler = (contacts) => {
    setContact([...contact, { id: uuidv4(), ...contacts }]);
  };


  useEffect(() => {
    localStorage.setItem(local_storage_key, JSON.stringify(contact));
  }, [contact]);


    const add = (e) => {
        e.preventDefault();
        if (name === "" || email === "") {
            alert("All fields are required");
            return;
        }
        addContactHandler({ name, email });
        setName("");
        setEmail("");
    };

    return (
        <div className='ui container main'>
            <h1>Add Contact</h1>
            <form className='ui form' onSubmit={add}>
                <div className='field'>
                    <label>Name</label>
                    <input 
                        type="text" 
                        name="name" 
                        placeholder="Name" 
                        value={name}  
                        onChange={(e) => setName(e.target.value)}
                    />
                </div>
                <div className='field'>
                    <label>Email</label>
                    <input 
                        type="email" 
                        name="email" 
                        placeholder="Email" 
                        value={email}  
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </div>

                <button className='ui button'>Add</button>
            </form>
        </div>
    );
}

export default AddContact;
