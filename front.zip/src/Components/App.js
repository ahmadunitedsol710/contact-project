import React, {useState} from 'react';
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import Header from './header';
import AddContact from './AddContact';
import ContactList from './ContactList';
import './App.css';

function App() {
  const local_storage_key = 'contact';
  const [contact, setContact] = useState([]);

  return (
    <div className='ui container'>
    <Router>
      <Header />
      <Routes>
          <Route path="/add" element={<AddContact setContact={setContact} contact={contact} local_storage_key={local_storage_key} />}/>
          
          <Route path="/"
          exact element={<ContactList contact={contact} setContact={setContact} local_storage_key={local_storage_key}/>}/>
      </Routes>
    </Router>
    </div>
  );
}

export default App;
