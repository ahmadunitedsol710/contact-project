import React, {useEffect} from 'react';
import { Link } from 'react-router-dom';
import ContactCard from './ContactCard';



function ContactList({contact, setContact}) {
  

    const deleteContactHandler = (id) => {
        const newContactList = contact.filter((contact) => {
            return contact.id !== id; //if contact id didn't match then return those id's and display on the screen
        });
    
        setContact(newContactList);
    };

    const rendercontactlist = contact.map((contact) => {
        return (
            <ContactCard contact={contact} clickHandler={deleteContactHandler} key={contact.id}></ContactCard>
        );
    });

    useEffect(() => {
            const getContacts = JSON.parse(localStorage.getItem('contact'));
            if(getContacts && getContacts.length > 0){
              setContact(getContacts);
            }
        }
        
      },[]);

    return (
        <div className='ui celled list'>
            <h1>
                Contact List
                <Link to="/add"><button className='ui button blue right'>Add Contact</button></Link>
            </h1>
            {rendercontactlist}
        </div>
    )
}


export default ContactList;